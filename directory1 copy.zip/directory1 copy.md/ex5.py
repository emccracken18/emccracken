my_name = "Elizabeth M. McCracken"
my_age = 17 # not a lie
my_height = 67 # inches
my_weight = 150 # lbs
my_eyes = 'Blue'
my_teeth = 'White'
my_hair = 'Red'
print "Let's talk about %s." % my_name
print "She's %d inches tall." % my_height
print "She's %d pounds heavy." % my_weight
print "Actually that's not too heavy."
print "She's got %s eyes and %s hair." % (my_eyes, my_hair)
print "Her teeth are usually %s depending on the coffee." % my_teeth
print "If I add %d, %d, and %d I get %d." % (
    my_age, my_height, my_weight, my_age + my_height + my_weight)
