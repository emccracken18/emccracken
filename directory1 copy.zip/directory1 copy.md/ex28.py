print True and True
print False and True
print 1 == 1 and 2 == 1
print "test" == "test"
print 1 == 1 or 2 != 1
print True and 1 == 1
print False and 0 != 0
print True or 1 == 1
print "test" == "testing"
print "test" == 1
print not (True and False)
print not (1 == 1 and 0 != 1)
print not (10 != 10 or 3 == 4)
print not "testing" == "testing" and "Lizzie" == "Cool gal"
print 1 == 1 and (not ("testing" == 1 or 1 == 0))
print "chunky" == "bacon" and (not (3 == 4 or 3 == 3))
print 3 == 3 and (not ("testing" == "testing" or "Python" == "Fun"))
