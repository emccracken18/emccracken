>>> things = ['a', 'b', 'c', 'd']
>>> print things[1]
b
>>> things[1] = 'z'
>>> print things[1]
z
>>> things
['a', 'z', 'c', 'd']



>>> stuff = {'name': 'Lizzie', 'age': 17, 'height': 6 * 10 + 7}
>>> print stuff['name']
Lizzie
>>> print stuff['age']
17
>>> print stuff['height']
67
>>> stuff['city'] = "Edina"
>>> print stuff['city']
Edina
